// ***
// *** You MUST modify this file.
// 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLENGTH 150

int countNotes(char * filename, double pitch){

// Open the CSV file for reading
//Check if the file was opened successfully
//MAXLENGTH is maximum number of characters in the line
//store each line of the file
// Read the header line to skip it
//count occurance of each pitch   
//consider using sscanf



}
