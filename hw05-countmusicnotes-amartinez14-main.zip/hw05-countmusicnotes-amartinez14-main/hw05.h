// ***
// *** DO NOT modify this file
// ***

#ifndef HW05_H
#define HW05_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int countNotes(char * filename, int pitch);
#endif
